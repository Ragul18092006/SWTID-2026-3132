from __future__ import annotations

from gemini_service import ai


def get_learning_recommendations(topic: str, level: str = "beginner") -> str:
    prompt = (
        "Create a personalized learning path for the topic below. The learner level is "
        f"{level}. Organize it from foundational to advanced topics. Include suggested "
        "time ranges, practice activities, checkpoints, and resource types (such as "
        "documentation, textbooks, videos, or practice sites). Do not invent specific "
        "URLs. Keep the plan realistic and concise.\n\n"
        f"Topic: {topic}"
    )
    return ai.generate(prompt)
