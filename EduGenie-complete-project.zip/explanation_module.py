from __future__ import annotations

import logging
from typing import Any

from config import settings
from gemini_service import ai

logger = logging.getLogger("edugenie.explanation")

_pipeline: Any | None = None
_pipeline_failed = False


def _local_pipeline() -> Any | None:
    global _pipeline, _pipeline_failed
    if _pipeline is not None or _pipeline_failed or not settings.use_local_explanation:
        return _pipeline
    try:
        from transformers import pipeline

        _pipeline = pipeline(
            "text2text-generation",
            model=settings.local_explanation_model,
            device=-1,
        )
        return _pipeline
    except Exception:
        _pipeline_failed = True
        logger.exception("Local explanation model could not be loaded; using Gemini fallback.")
        return None


def explain_concept(topic: str) -> str:
    """Explain a concept simply, preferring the documented local LaMini model."""
    local = _local_pipeline()
    if local is not None:
        prompt = (
            "Explain this educational concept in simple language for a beginner. "
            "Use short paragraphs and one small example if useful. Do not invent facts.\n\n"
            f"Concept: {topic}"
        )
        try:
            result = local(prompt, max_new_tokens=180, do_sample=False)
            if result and result[0].get("generated_text"):
                return result[0]["generated_text"].strip()
        except Exception:
            logger.exception("Local explanation failed; using Gemini fallback.")

    prompt = (
        "You are EduGenie, an educational tutor. Explain the concept below in simple, "
        "accurate language for a student. Start with a one-sentence definition, then "
        "give 3-5 short bullet points and a simple example.\n\n"
        f"Concept: {topic}"
    )
    return ai.generate(prompt)
