from __future__ import annotations

from pydantic import BaseModel, Field, ValidationError

from gemini_service import ai


class QuizQuestion(BaseModel):
    question: str = Field(min_length=1)
    options: list[str] = Field(min_length=4, max_length=4)
    answer: str = Field(min_length=1)
    explanation: str = Field(default="")


def _clean_questions(data: object) -> list[QuizQuestion]:
    if isinstance(data, dict):
        data = data.get("questions", [])
    if not isinstance(data, list):
        raise RuntimeError("Quiz response did not contain a question list.")
    try:
        questions = [QuizQuestion.model_validate(item) for item in data]
    except ValidationError as exc:
        raise RuntimeError("Quiz response had an invalid structure.") from exc
    if len(questions) != 3:
        raise RuntimeError("Quiz generation did not return exactly 3 questions.")
    for q in questions:
        if q.answer not in q.options:
            raise RuntimeError("Quiz answer must match one of the options.")
    return questions


def generate_quiz(text: str) -> list[QuizQuestion]:
    prompt = (
        "Create exactly 3 multiple-choice questions from the educational passage below. "
        "Each question must have exactly 4 options and one correct answer. Keep every "
        "question answerable from the passage. Return JSON with this exact shape: "
        '{"questions":[{"question":"...","options":["...","...","...","..."],'
        '"answer":"...","explanation":"..."}]}. No markdown.\n\n'
        f"Passage:\n{text}"
    )
    return _clean_questions(ai.generate_json(prompt))
