from __future__ import annotations

import json
import logging
from typing import Any

from config import settings

logger = logging.getLogger("edugenie.gemini")


class GeminiService:
    """Small wrapper around Google's current GenAI Python SDK."""

    def __init__(self) -> None:
        self._client: Any | None = None
        self._types: Any | None = None
        if settings.gemini_api_key:
            self._initialize_client()

    def _initialize_client(self) -> None:
        try:
            from google import genai
            from google.genai import types
        except ImportError as exc:
            raise RuntimeError(
                "The google-genai package is missing. Run: pip install -r requirements.txt"
            ) from exc
        self._client = genai.Client(api_key=settings.gemini_api_key)
        self._types = types

    @property
    def configured(self) -> bool:
        return self._client is not None

    def generate(self, prompt: str, *, json_mode: bool = False) -> str:
        if not self._client:
            if not settings.gemini_api_key:
                raise RuntimeError(
                    "Gemini is not configured. Add GEMINI_API_KEY to your .env file."
                )
            self._initialize_client()

        config = self._types.GenerateContentConfig(
            temperature=0.3,
            response_mime_type="application/json" if json_mode else "text/plain",
        )
        response = self._client.models.generate_content(
            model=settings.gemini_model,
            contents=prompt,
            config=config,
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text.strip()

    def generate_json(self, prompt: str) -> Any:
        raw = self.generate(prompt, json_mode=True)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            logger.exception("Gemini returned invalid JSON: %s", raw[:500])
            raise RuntimeError("Gemini returned invalid JSON.") from exc


ai = GeminiService()
