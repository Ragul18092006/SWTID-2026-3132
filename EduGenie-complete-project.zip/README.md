# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a lightweight educational assistant based on the project document: FastAPI backend + HTML/CSS frontend, with separate modules for concept explanation, Q&A, quiz generation, summarization, and personalized learning paths.

## Project structure

```text
EduGenie/
├── main.py
├── config.py
├── gemini_service.py
├── explanation_module.py
├── qna.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── schemas.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── app.js
│   └── style.css
└── tests/
    └── test_app.py
```

## Requirements

- Python 3.10+
- A Gemini API key in an environment variable named `GEMINI_API_KEY`
- Internet access for Gemini-backed features
- The local explanation model is optional but enabled by default. On its first use it downloads `MBZUAI/LaMini-Flan-T5-783M` and can require substantial RAM/disk. Set `USE_LOCAL_EXPLANATION=false` to skip it and use Gemini for explanations too.

## VS Code setup — Windows PowerShell

```powershell
cd path\to\EduGenie
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Open `.env` and replace `your_gemini_api_key_here` with your own key. Never commit `.env` to Git.

Run:

```powershell
uvicorn main:app --reload
```

Open `http://127.0.0.1:8000` in a browser.

## macOS/Linux

```bash
cd /path/to/EduGenie
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
uvicorn main:app --reload
```

## Test the API

Health check:

```bash
curl http://127.0.0.1:8000/health
```

Q&A:

```bash
curl -X POST http://127.0.0.1:8000/qa \
  -H "Content-Type: application/json" \
  -d '{"question":"Which is the largest ocean?"}'
```

Quiz:

```bash
curl -X POST http://127.0.0.1:8000/quiz \
  -H "Content-Type: application/json" \
  -d '{"text":"Water covers most of Earth and is essential for life."}'
```

Run automated tests:

```bash
pytest -q
```

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | Web interface |
| GET | `/health` | Server/AI configuration status |
| POST | `/qa` | Question answering |
| POST | `/explain` | Simple concept explanation |
| POST | `/quiz` | Exactly 3 MCQs, 4 options each |
| POST | `/summarize` | Educational text summary |
| POST | `/learn/recommendations` | Personalized learning path |

## Gemini configuration

The application keeps the Gemini key on the backend. The browser never receives the API key. The SDK is initialized from `GEMINI_API_KEY`, and the model is controlled by `GEMINI_MODEL`.

The project document contains older `google.generativeai` / Gemini 1.5 snippets. This implementation uses the current `google-genai` Python SDK and a current model name configured in `.env`. If your Google AI account exposes a different model, change `GEMINI_MODEL` without changing the application code.

## Security note

Do not paste API keys into source code, screenshots, Git commits, or the frontend. If a real key was ever placed in the project document or shared publicly, rotate/revoke it and create a replacement before using this project.

## Troubleshooting

### `Gemini is not configured`
Check that `.env` exists in the project root and contains `GEMINI_API_KEY=...`. Restart Uvicorn after editing `.env`.

### Local explanation model is slow or fails to load
Set:

```env
USE_LOCAL_EXPLANATION=false
```

Then restart the server. `/explain` will use Gemini instead.

### `ModuleNotFoundError`
Activate `.venv` and run `pip install -r requirements.txt` again.

### Port already in use
Run:

```bash
uvicorn main:app --reload --port 8001
```

Then open `http://127.0.0.1:8001`.
