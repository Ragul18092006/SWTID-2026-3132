from __future__ import annotations

from gemini_service import ai


def answer_question(question: str) -> str:
    prompt = (
        "You are EduGenie, a careful educational assistant. Answer the student's "
        "question clearly and concisely. Explain important terms briefly, show steps "
        "for calculations when needed, and say when something is uncertain. Do not "
        "pretend to know information you cannot verify.\n\n"
        f"Question: {question}"
    )
    return ai.generate(prompt)
