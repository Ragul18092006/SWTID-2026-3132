from __future__ import annotations

import logging
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from config import settings
from explanation_module import explain_concept
from gemini_service import ai
from learning_path import get_learning_recommendations
from qna import answer_question
from quiz_module import generate_quiz
from schemas import LearningPathRequest, QuestionRequest, TextRequest
from summary_module import summarize_text

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("edugenie")

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title="EduGenie - Google Gemini Powered Learning Assistant",
    description="Educational assistant with Q&A, explanation, quizzes, summaries and learning paths.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.cors_origins),
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
async def health() -> dict[str, object]:
    return {"status": "ok", "gemini_configured": ai.configured}


@app.post("/qa")
async def qa(payload: QuestionRequest) -> dict[str, str]:
    try:
        return {"answer": answer_question(payload.question)}
    except Exception as exc:
        logger.exception("Q&A failed")
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/explain")
async def explain(payload: TextRequest) -> dict[str, str]:
    try:
        return {"explanation": explain_concept(payload.text)}
    except Exception as exc:
        logger.exception("Explanation failed")
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/quiz")
async def quiz(payload: TextRequest) -> dict[str, object]:
    try:
        return {"questions": [q.model_dump() for q in generate_quiz(payload.text)]}
    except Exception as exc:
        logger.exception("Quiz failed")
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/summarize")
async def summarize(payload: TextRequest) -> dict[str, str]:
    try:
        return {"summary": summarize_text(payload.text)}
    except Exception as exc:
        logger.exception("Summary failed")
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/learn/recommendations")
async def recommendations(payload: LearningPathRequest) -> dict[str, str]:
    try:
        return {"recommendations": get_learning_recommendations(payload.topic, payload.level)}
    except Exception as exc:
        logger.exception("Learning path failed")
        raise HTTPException(status_code=502, detail=str(exc)) from exc
