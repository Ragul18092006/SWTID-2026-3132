const task = document.getElementById('task');
const input = document.getElementById('input');
const level = document.getElementById('level');
const levelWrap = document.getElementById('levelWrap');
const inputLabel = document.getElementById('inputLabel');
const submit = document.getElementById('submit');
const clear = document.getElementById('clear');
const result = document.getElementById('result');
const loading = document.getElementById('loading');
const status = document.getElementById('status');

const labels = {
  qa: ['Your question', 'Example: Which is the largest ocean?'],
  explain: ['Concept or topic', 'Example: Explain the Pythagoras theorem'],
  quiz: ['Topic or passage', 'Paste a passage or enter a topic for a 3-question quiz'],
  summarize: ['Text to summarize', 'Paste the educational passage here'],
  learn: ['Topic to learn', 'Example: SQL, Python, Biology, Physics'],
};

function updateForm() {
  const [label, placeholder] = labels[task.value];
  inputLabel.textContent = label;
  input.placeholder = placeholder;
  levelWrap.classList.toggle('hidden', task.value !== 'learn');
}

task.addEventListener('change', updateForm);
clear.addEventListener('click', () => {
  input.value = '';
  result.className = 'result empty';
  result.textContent = 'Your result will appear here.';
});

function showText(text) {
  result.className = 'result';
  result.textContent = text;
}

function showQuiz(questions) {
  result.className = 'result';
  result.innerHTML = '';
  questions.forEach((q, i) => {
    const card = document.createElement('article');
    card.className = 'quiz-question';
    const title = document.createElement('h3');
    title.textContent = `${i + 1}. ${q.question}`;
    card.appendChild(title);
    const list = document.createElement('ol');
    list.type = 'A'.charCodeAt(0) ? 'A' : 'a';
    q.options.forEach(option => {
      const item = document.createElement('li');
      item.textContent = option;
      list.appendChild(item);
    });
    card.appendChild(list);
    const answer = document.createElement('p');
    answer.innerHTML = `<strong>Answer:</strong> ${escapeHtml(q.answer)}${q.explanation ? ` — ${escapeHtml(q.explanation)}` : ''}`;
    card.appendChild(answer);
    result.appendChild(card);
  });
}

function escapeHtml(value) {
  const div = document.createElement('div');
  div.textContent = value;
  return div.innerHTML;
}

async function runTask() {
  const text = input.value.trim();
  if (!text) {
    showText('Please enter a question, topic, or passage first.');
    return;
  }

  submit.disabled = true;
  loading.classList.remove('hidden');
  result.className = 'result';
  result.textContent = 'Generating…';

  const routes = {
    qa: ['/qa', { question: text }],
    explain: ['/explain', { text }],
    quiz: ['/quiz', { text }],
    summarize: ['/summarize', { text }],
    learn: ['/learn/recommendations', { topic: text, level: level.value }],
  };

  try {
    const [url, body] = routes[task.value];
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Request failed.');

    if (task.value === 'qa') showText(data.answer);
    else if (task.value === 'explain') showText(data.explanation);
    else if (task.value === 'summarize') showText(data.summary);
    else if (task.value === 'learn') showText(data.recommendations);
    else showQuiz(data.questions);
  } catch (error) {
    result.className = 'result error';
    result.textContent = error.message || 'Something went wrong.';
  } finally {
    submit.disabled = false;
    loading.classList.add('hidden');
  }
}

submit.addEventListener('click', runTask);

fetch('/health')
  .then(r => r.json())
  .then(data => {
    status.textContent = data.gemini_configured ? 'AI connected' : 'API key needed';
  })
  .catch(() => { status.textContent = 'Server unavailable'; });

updateForm();
