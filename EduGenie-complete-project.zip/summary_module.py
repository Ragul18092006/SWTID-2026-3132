from __future__ import annotations

from gemini_service import ai


def summarize_text(text: str) -> str:
    prompt = (
        "Summarize the educational passage in simple language. Preserve the central "
        "facts, definitions, names, dates, formulas, and relationships. Remove repetition. "
        "Use a short title followed by concise bullet points when appropriate.\n\n"
        f"Passage:\n{text}"
    )
    return ai.generate(prompt)
