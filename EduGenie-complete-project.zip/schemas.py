from __future__ import annotations

from pydantic import BaseModel, Field, field_validator


class TextRequest(BaseModel):
    text: str = Field(min_length=1, max_length=12000)

    @field_validator("text")
    @classmethod
    def normalize_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Input cannot be empty.")
        return value


class QuestionRequest(BaseModel):
    question: str = Field(min_length=1, max_length=4000)

    @field_validator("question")
    @classmethod
    def normalize_question(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Question cannot be empty.")
        return value


class LearningPathRequest(BaseModel):
    topic: str = Field(min_length=1, max_length=1000)
    level: str = Field(default="beginner", max_length=50)

    @field_validator("topic", "level")
    @classmethod
    def normalize(cls, value: str) -> str:
        return value.strip()
