from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


def _csv(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


@dataclass(frozen=True)
class Settings:
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
    local_explanation_model: str = os.getenv(
        "LOCAL_EXPLANATION_MODEL", "MBZUAI/LaMini-Flan-T5-783M"
    )
    use_local_explanation: bool = os.getenv("USE_LOCAL_EXPLANATION", "true").lower() in {
        "1", "true", "yes", "on"
    }
    host: str = os.getenv("HOST", "127.0.0.1")
    port: int = int(os.getenv("PORT", "8000"))
    cors_origins: tuple[str, ...] = tuple(_csv(
        os.getenv("CORS_ORIGINS", "http://127.0.0.1:8000,http://localhost:8000")
    ))
    max_input_chars: int = int(os.getenv("MAX_INPUT_CHARS", "12000"))


settings = Settings()
